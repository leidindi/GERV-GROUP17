from agent import Agent
from environment import *
import copy


class Node:
    def __init__(self, valueFunction=1, alpha=-float('inf'), beta=float('inf'), parent="root", move=None, state=None):
        self.alpha = alpha
        self.beta = beta

        self.parent = parent

        self.move = move

        self.best = None
        self.valueFunction = valueFunction

        self.state = state
        self.children = []


class Tree:
    def __init__(self, limit=5, depth=0, state=None, env=None):
        self.limit = limit
        self.depth = depth
        self.state = state
        self.root = None
        self.env = env
        if state == None:
            raise EnvironmentError

    def terminalstate(self):
        if "B" in self.state.board[0] or "W" in self.state.board[-1]:
            return True
        return False

    def solve(self, parent=None, depth=0):
        if self.terminalstate() or depth >= self.limit:
            return parent.valueFunction

        maximizing_player = depth % 2 == 0
        if maximizing_player:

            best_value = -float('inf')

            for move in self.env.get_legal_moves(self.state):
                # (self, valueFunction=1, alpha=-float('inf'), beta=float('inf'), parent="root",move=None,state=None):
                self.env.move(self.state, move)

                nextState = self.env.current_state
                noda = Node(parent=parent, move=move, state=nextState, valueFunction=self.env.valueFunction(nextState))
                value = self.solve(noda, depth + 1)
                self.env.undo_move(noda.state, noda.move)

                best_value = max(best_value, value)
                parent.alpha = max(parent.alpha, best_value)
                if parent.beta <= parent.alpha:
                    break

            return best_value

        else:
            best_value = float('inf')
            for move in self.env.get_legal_moves(self.state):

                self.env.move(self.state, move)
                nextState = self.env.current_state
                noda = Node(parent=parent, move=move, state=nextState, valueFunction=self.env.valueFunction(nextState))
                value = self.solve(noda, depth + 1)

                self.env.undo_move(noda.state, noda.move)
                best_value = min(best_value, value)
                parent.beta = min(parent.beta, best_value)
                if parent.beta <= parent.alpha:
                    break
            return best_value

class MyAgent(Agent):

    def __init__(self):
        self.role = None
        self.play_clock = None
        self.my_turn = False
        self.width = 0
        self.height = 0
        self.env = None

    def get_best_move(self, limit=3):
        # gera iterative deepening þar sem ég passa upp á tímann
        best = -10000
        bestmove = "nomove"
        limit = 5
        legals = self.env.get_legal_moves(self.env.current_state)
        for move in legals:
            tree = Tree(state=self.env.current_state, limit=limit, env=self.env)
            # valueFunction=1, alpha=-float('inf'), beta=float('inf'), parent="root", move=None, state=None):
            movenode = Node(state=self.env.current_state, move=move)
            solved = tree.solve(movenode)
            if solved > best:
                best = solved
                bestmove = move
        if bestmove == "nomove":
            raise AssertionError
        print(bestmove)
        return bestmove

    # start() is called once before you have to select the first action. Use it to initialize the agent.
    # role is either "white" or "black" and play_clock is the number of seconds after which nextAction must return.
    def start(self, role, width, height, play_clock):
        self.play_clock = play_clock
        self.role = role
        self.my_turn = role != 'white'
        # we will flip my_turn on every call to next_action, so we need to start with False in case
        #  our action is the first
        self.width = width
        self.height = height
        # TODO: add your own initialization code here
        self.env = Environment(width, height)

    def next_action(self, last_action):
        if last_action:
            if self.my_turn and self.role == 'white' or not self.my_turn and self.role != 'white':
                last_player = 'white'
            else:
                last_player = 'black'
            print("%s moved from %s to %s" % (last_player, str(last_action[0:2]), str(last_action[2:4])))
            self.env.move(self.env.current_state, [i - 1 for i in last_action])
        else:
            print("first move!")

        # update turn (above that line it myTurn is still for the previous state)
        self.my_turn = not self.my_turn
        if self.my_turn:
            move = self.get_best_move()
            return "(move " + " ".join(map(str, [i + 1 for i in move])) + ")"
            # send the move first, then update your own world
            # if the move is not legal the game player will give you a random move
        else:
            return "noop"

    # this method is called when the environment has reached a terminal state
    # override it to reset the agent
    def cleanup(self, last_move):
        print("cleanup called")
        return
