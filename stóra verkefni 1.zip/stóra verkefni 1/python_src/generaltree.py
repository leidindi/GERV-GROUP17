class GeneralNode:
    def __init__(self, data = None, node_lis=None, alpha = -100000000, beta = 1000000000, parent = None):
        self.alpha = alpha
        self.beta = beta
        self.parent = parent
        self.data = data
        if node_lis == None:
            self.node_lis = []
        else:
            self.node_lis = node_lis

class GeneralTree:
    def __init__(self):
        self.root = None
    def __str__(self):
        return self.print_tree()
    def _print_tree_recur(self,node):
        if node == None:
            return ""
        print(str(node.data), end=" ")
        for child_node in node.node_lis:
            self._print_tree_recur(child_node)
    def print_tree(self):
        self._print_tree_recur(self.root)
        return "\n"
    def populate_tree(self):
        self.root = self.populate_tree_recur()

    def populate_tree_recur(self):
        data = input("input value : ")
        if data == "":
            return ""
        node = GeneralNode(data)
        while True:
            child = self.populate_tree_recur()
            if child == "":
                break
            node.node_lis.append(child)
        return node
#b2 = GeneralTree()
#b2.populate_tree()
#print(b2)